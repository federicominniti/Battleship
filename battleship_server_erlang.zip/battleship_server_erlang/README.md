battleship_server_erlang
=====

An OTP application

Build
-----

    $ rebar3 compile
